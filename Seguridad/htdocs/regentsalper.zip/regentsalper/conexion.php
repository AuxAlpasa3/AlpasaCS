<?php
//Servidor, Usuario, Password, NombreBD
$mysqli = new mysqli('localhost', 'root', '', 'alpasaapp');